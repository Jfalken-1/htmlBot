package com.dennis.tues.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		// Start the Spring Boot application
		ApplicationContext context = SpringApplication.run(Application.class, args);

		// Get the ChatbotService and HTMLservice beans
		ChatbotService chatbotService = context.getBean(ChatbotService.class);
		HTMLservice htmlService = context.getBean(HTMLservice.class);

		// Generate the HTML content
		String htmlRequest = "make a little happy face";
		String generatedHtml = chatbotService.getChatbotResponse(htmlRequest);

		// Store the generated HTML in the HTMLservice
		htmlService.setHtmlContent(generatedHtml);

		// Print confirmation
		System.out.println("HTML content generated and stored: ");
		System.out.println(generatedHtml); // Verify the generated content
	}
}
