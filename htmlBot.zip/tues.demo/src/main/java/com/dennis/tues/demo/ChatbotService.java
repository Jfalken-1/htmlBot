package com.dennis.tues.demo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class ChatbotService {

    // Inject API key and URL from application properties
    @Value("${openai.api.key}")
    private String apiKey;

    @Value("${openai.api.url:https://api.openai.com/v1/chat/completions}")
    private String apiUrl;

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public String getChatbotResponse(String userMessage) {
        OkHttpClient client = new OkHttpClient();

        // JSON payload for the OpenAI API request
// JSON payload for the OpenAI API request
        String requestBody = "{"
                + "\"model\":\"gpt-3.5-turbo\","
                + "\"messages\":["
                + "{\"role\":\"system\",\"content\":\"You provide html code based off the user message. you never return anything but the html code.\"},"
                + "{\"role\":\"user\",\"content\":\"" + userMessage + "\"}]"
                + "}";

        // Build the HTTP request
        Request request = new Request.Builder()
                .url(apiUrl)
                .post(RequestBody.create(requestBody, JSON))
                .addHeader("Authorization", "Bearer " + apiKey)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String responseBody = response.body().string();

                // Parse JSON response to extract the "content" field
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode rootNode = objectMapper.readTree(responseBody);
                JsonNode contentNode = rootNode.path("choices").get(0).path("message").path("content");

                // Return the extracted content (AI's reply)
                return contentNode.asText();
            } else {
                return "Error: " + response.code() + " - " + response.message();
            }
        } catch (IOException e) {
            return "Error: Unable to communicate with OpenAI API - " + e.getMessage();
        }
    }

//    private String extractHtmlContent(String jsonResponse) {
//        try {
//            ObjectMapper objectMapper = new ObjectMapper();
//            JsonNode rootNode = objectMapper.readTree(jsonResponse);
//            String rawHtml = rootNode.path("choices").get(0).path("message").path("content").asText().trim();
//
//            // Remove Markdown-style code fences if present
//            if (rawHtml.startsWith("```html")) {
//                rawHtml = rawHtml.replaceFirst("```html", "").trim();
//            }
//            if (rawHtml.endsWith("```")) {
//                rawHtml = rawHtml.substring(0, rawHtml.length() - 3).trim();
//            }
//
//            return rawHtml;
//        } catch (Exception e) {
//            return "Error: Unable to parse response - " + e.getMessage();
//        }
//    }


}

