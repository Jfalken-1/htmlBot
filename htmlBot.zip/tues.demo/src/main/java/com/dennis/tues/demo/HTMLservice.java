package com.dennis.tues.demo;

import org.springframework.stereotype.Service;

@Service
public class HTMLservice {
    private String htmlContent;

    public String getHtmlContent() {
        return htmlContent;
    }

    public void setHtmlContent(String htmlContent) {
        this.htmlContent = htmlContent;
    }
}
